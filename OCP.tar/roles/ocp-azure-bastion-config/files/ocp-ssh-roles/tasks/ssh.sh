#!/bin/bash
 ssh-keygen -q -t rsa -f ~/.ssh/id_rsa -N ""

