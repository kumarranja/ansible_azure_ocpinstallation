oc new-project jenkins
oc new-app jenkins-persistent
