#!/bin/bash
##################################################################################################
### Script to develop named.conf and zone DB files for BIND Master and Slave servers #############
### Author: Gunasekaran.Govindasamy@in.fujitsu.com                                   #############
### version: 1                                                                       #############
### Release: 10.06.2018                                                              #############
##################################################################################################
## Variable definition
WORK_DIR=$(dirname $0)
VM_LIST_FILE=$1
DOMAIN_NAME=$2
DNS_MASTER_NAME=$3
DNS_SLAVE_NAME=$4
TEMP_DIR=$5
DNS_MASTER_IP=$(grep -w ${DNS_MASTER_NAME} $VM_LIST_FILE | awk -F, '{print $2}')
DNS_SLAVE_IP=$(grep -w ${DNS_SLAVE_NAME} $VM_LIST_FILE | awk -F, '{print $2}')
NET_ID=$(awk -F, '{print $NF}' $VM_LIST_FILE | awk -F '.' '{print $1"."$2".0.0"}' | sort -u )
FWD_ZONE_FILE="fwd.${DOMAIN_NAME}.db"
SERIAL_STAMP=$(date "+%Y%m%d")01

## Create the first part of the PTR zone file
sed "s/SERIAL_STAMP/${SERIAL_STAMP}/g" $WORK_DIR/zone_template | sed "s/DNS_MASTER/${DNS_MASTER_NAME}/g" | sed "s/DNS_SLAVE/${DNS_SLAVE_NAME}/g" | sed "s/DOMAIN_NAME/${DOMAIN_NAME}/g" > ${TEMP_DIR}/zone_file.1.$$
## Create PTR zone files
for IP_RANGE in $(awk -F, '{print $NF}' $VM_LIST_FILE | awk -F '.' '{print $1"."$2"."$3}' | sort -u)
do
	#echo $IP_RANGE
	REV_IP_RANGE=$(echo $IP_RANGE | awk -F'.' '{print $3"."$2"."$1}')
	echo ";PTR Record IP address to HostName" > ${TEMP_DIR}/${REV_IP_RANGE}.PTR.$$
	grep ",${IP_RANGE}\." $VM_LIST_FILE | awk -F, '{print $2,$1}' | sed "s/${IP_RANGE}\.//" | awk '{print $1"  IN  PTR  "$2}' | sed "s/$/.${DOMAIN_NAME}./" >> ${TEMP_DIR}/${REV_IP_RANGE}.PTR.$$
	cat ${TEMP_DIR}/zone_file.1.$$ ${TEMP_DIR}/${REV_IP_RANGE}.PTR.$$ > ${TEMP_DIR}/${REV_IP_RANGE}.db
done

## Create forward zone file
echo ";IP address of Name Server" > ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$
grep -w ${DNS_MASTER_NAME} $VM_LIST_FILE | awk -F, '{print $1"  IN  A  "$2}' >> ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$
echo ";IP address of Name Server" >> ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$
grep -w ${DNS_SLAVE_NAME} $VM_LIST_FILE | awk -F, '{print $1"  IN  A  "$2}' >> ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$
echo ";A - Record HostName To Ip Address" >> ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$
awk -F, '{print $1"  IN  A  "$2}' $VM_LIST_FILE >> ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$
cat ${TEMP_DIR}/zone_file.1.$$ ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$ > ${TEMP_DIR}/fwd.${DOMAIN_NAME}.db

## Create Master named.conf 
sed "s/VNET_IP_RANGE/${NET_ID}/g" $WORK_DIR/master_named_template.conf | sed "s/DNS_SLAVE_IP/${DNS_SLAVE_IP}/g" > ${TEMP_DIR}/master_named.conf.$$
sed "s/ZONE_NAME/${DOMAIN_NAME}/g" $WORK_DIR/master_zone_stanza_template | sed "s/ZONE_FILE/${FWD_ZONE_FILE}/g" | sed "s/DNS_SLAVE_IP/${DNS_SLAVE_IP}/g" > ${TEMP_DIR}/master_zone_entries.$$
for IP_RANGE in $(awk -F, '{print $NF}' $VM_LIST_FILE | awk -F '.' '{print $1"."$2"."$3}' | sort -u)
do
	REV_IP_RANGE=$(echo $IP_RANGE | awk -F'.' '{print $3"."$2"."$1}')
	PTR_ZONE_NAME="${REV_IP_RANGE}.in-addr.arpa"
	PTR_ZONE_FILE="${REV_IP_RANGE}.db"
	sed "s/ZONE_NAME/${PTR_ZONE_NAME}/g" $WORK_DIR/master_zone_stanza_template | sed "s/ZONE_FILE/${PTR_ZONE_FILE}/g" | sed "s/DNS_SLAVE_IP/${DNS_SLAVE_IP}/g" >> ${TEMP_DIR}/master_zone_entries.$$
done
cat ${TEMP_DIR}/master_named.conf.$$ ${TEMP_DIR}/master_zone_entries.$$ > ${TEMP_DIR}/master_named.conf

## Create Slave named.conf
sed "s/VNET_IP_RANGE/${NET_ID}/g" $WORK_DIR/slave_named_template.conf  > ${TEMP_DIR}/slave_named.conf.$$
sed "s/ZONE_NAME/${DOMAIN_NAME}/g" $WORK_DIR/slave_zone_stanza_template | sed "s/ZONE_FILE/${FWD_ZONE_FILE}/g" | sed "s/DNS_MASTER_IP/${DNS_MASTER_IP}/g" > ${TEMP_DIR}/slave_zone_entries.$$
for IP_RANGE in $(awk -F, '{print $NF}' $VM_LIST_FILE | awk -F '.' '{print $1"."$2"."$3}' | sort -u)
do
        REV_IP_RANGE=$(echo $IP_RANGE | awk -F'.' '{print $3"."$2"."$1}')
        PTR_ZONE_NAME="${REV_IP_RANGE}.in-addr.arpa"
        PTR_ZONE_FILE="${REV_IP_RANGE}.db"
        sed "s/ZONE_NAME/${PTR_ZONE_NAME}/g" $WORK_DIR/slave_zone_stanza_template | sed "s/ZONE_FILE/${PTR_ZONE_FILE}/g" | sed "s/DNS_MASTER_IP/${DNS_MASTER_IP}/g" >> ${TEMP_DIR}/slave_zone_entries.$$
done
cat ${TEMP_DIR}/slave_named.conf.$$ ${TEMP_DIR}/slave_zone_entries.$$ > ${TEMP_DIR}/slave_named.conf


## Remove temp files
for FILE in  ${TEMP_DIR}/zone_file.1.$$ ${TEMP_DIR}/*.PTR.$$ ${TEMP_DIR}/fwd.${DOMAIN_NAME}.$$ ${TEMP_DIR}/master_named.conf.$$ ${TEMP_DIR}/master_zone_entries.$$ ${TEMP_DIR}/slave_named.conf.$$ ${TEMP_DIR}/slave_zone_entries.$$
do
	rm $FILE
done
