##################################################################
# Copyright - Fujitsu Consulting India
# Author : Gunasekaran Govindasamy ( Gunasekaran.Govindasamy@in.fujitsu.com
# Release : 11.06.2018
#------------------------------------------------------------------
# This ansible role configures BIND based DNS service in following steps
# 1. Installs BIND packages
# 2. Creates named.conf and required zone files
# 3. Copies the named.conf and Zone files to Master and Slave server
# 4. Restarts the named service in Slave and Master server
#------------------------------------------------------------------
# This role requires following mandatory arguments
# 1. DNS domain name - E.g. "abc.local"
# 2. Hostname of DNS Master - E.g. "dns-master"
# 3. Hostname of DNS Slave - E.g. "dns-slave"
# 4. Filename which contains comma separated list of hostnames and IP address - E.g. "dns-master,10.0.0.100"
#-------------------------------------------------------------------
# Dependencies and Limitations
# 1. This role depends on the ansible host aliases - "dns-master" and "dns-slave" , and the host variable "dns-role" in the host inventory file
#
#[all]
#dns-master ansible_host=<IP> dns_role=master
#dns-slave  ansible_host=<IP> dns_role=slave
#
# 2. This role is limited to "Redhat Linux - RHEL 7"
#
# 3. Before using this role - make sure the following settings are configured at master and slave server
#	a. Configure Hostname and FQDN
#	b. Enable port 53 for tcp and udp in firewalld / Ip table whichever its running
#
# 4. This role is developed to support the DNS server configuration in Openshift installation - It's up to the users to use this role for different scenario
#------------------------------------------------------------------
# Sample files for reference:
# 1. sample_playbook.yaml - Refer to know how to use this role
# 2. sample_hosts - Refer for sample hosts entries
# 3. sample_vm.list - Refer for format of sample hostname,IPaddress list 
#######################################################################
